﻿//------------------------------------------------------------------------------
// <generowane automatycznie>
//     Ten kod został wygenerowany przez narzędzie.
//
//     Zmiany w tym pliku mogą spowodować niewłaściwe zachowanie i zostaną utracone
//     w przypadku ponownego wygenerowania kodu. 
// </generowane automatycznie>
//------------------------------------------------------------------------------

namespace projekt
{


    public partial class WebForm3
    {

        /// <summary>
        /// Kontrolka form1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;

        /// <summary>
        /// Kontrolka logout_button.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button logout_button;

        /// <summary>
        /// Kontrolka login_session.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label login_session;

        /// <summary>
        /// Kontrolka Panel1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Panel Panel1;

        /// <summary>
        /// Kontrolka nazwa_towaru_text.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox nazwa_towaru_text;

        /// <summary>
        /// Kontrolka podaj_ilosc_text.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox podaj_ilosc_text;

        /// <summary>
        /// Kontrolka odejmij_towar_button.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button odejmij_towar_button;

        /// <summary>
        /// Kontrolka dodaj_button.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button dodaj_button;

        /// <summary>
        /// Kontrolka cena_towaru_text.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox cena_towaru_text;

        /// <summary>
        /// Kontrolka zmien_cene_towaru.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button zmien_cene_towaru;

        /// <summary>
        /// Kontrolka nowy_towar_nazwa.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox nowy_towar_nazwa;

        /// <summary>
        /// Kontrolka nowy_towar_ilosc.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox nowy_towar_ilosc;

        /// <summary>
        /// Kontrolka nowy_towar_cena.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox nowy_towar_cena;

        /// <summary>
        /// Kontrolka dodaj_nowy_button.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button dodaj_nowy_button;

        /// <summary>
        /// Kontrolka lblError.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblError;
    }
}
